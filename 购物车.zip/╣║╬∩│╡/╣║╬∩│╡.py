import time
goods = [
{"name": "电脑", "price": 1999},
{"name": "鼠标", "price": 10},
{"name": "游艇", "price": 20},
{"name": "美女", "price": 998},
]

# 验证帐号密码
def con(name, pwd):
    with open('file.user', 'r', encoding='UTF-8') as f:
        name_test = f.readline().strip()
        pwd_test = f.readline().strip()
        if name == name_test and pwd == pwd_test:
            return True
        else:
            return False



# 写购买记录
def write_shop_file(b):
    with open('file.shop', 'w+', encoding='UTF-8') as f:
        for i in b:
            a = i
            f.write(str(a))
            f.write('\n')
        f.flush()


# 写金额
def write_money_file(money):
    with open('file.money', 'w+', encoding='UTF-8') as f:
        f.write(str(money))
        f.flush()



# 读历史购买记录
def read_shop_file():
    with open('file.shop', 'r', encoding='UTF-8') as f:
        old_res = []
        for i in f:
            old_res.append(eval(i.strip()))
        return old_res


# 读历史金额
def read_money_file():
    with open('file.money', 'r', encoding='UTF-8') as f:
        money = int(f.read().strip())
        return money

# 继续购买
def old_buy():
    money = read_money_file()
    old_res = read_shop_file()
    while True:
        print('----------商品列表------------')
        for index, i in enumerate(goods):
            print(index, i['name'], i['price'])
        num = input('请问需要购买什么？输入商品编号,或者按Q退出:')
        if num.isdigit():
            num = int(num)
            if num >= 0 and num <=len(goods)-1 and money >= goods[num]['price']:
                    old_res.append(goods[num])
                    money -= goods[num]['price']
                    print('你的金额还剩下:''\033[1;31;m%s\033[0m' % money)
                    print('\033[1;31;m%s\033[0m' % '成功加入购物车')
            elif num >= 0 and num <= len(goods)-1 and money < goods[num]['price']:
                print('\033[1;31;m%s\033[0m' % '余额不足')
            else:
                print('输入商品不存在,请重新输入')
        elif num == 'q' or num =='Q':
            if len(old_res) > 0:
                print('你的金额还剩下:''\033[1;31;m%s\033[0m' % money)
                print('你总购买商品如下:')
                for index, i in enumerate(old_res):
                    print('\033[1;31;m', end='')
                    print(index, i['name'], i['price'])
                    print('\033[0m', end='')
                time.sleep(1)
                print('欢迎下次光临')
                write_shop_file(old_res)
                write_money_file(money)
            break
        else:
            print('输入有误，请重新输入')
            continue



#新购买
def new_buy():
    new_res = []
    money = int(input('请输入金额：'))
    while True:
        print('----------商品列表------------')
        for index, i in enumerate(goods):
            print(index, i['name'], i['price'])
        num = input('请问需要购买什么？输入商品编号,或者按Q退出:')
        if num.isdigit():
            num = int(num)
            if num >= 0 and num <=len(goods)-1 and money >= goods[num]['price']: #判断输入是否在索引内
                    new_res.append(goods[num])
                    money -= goods[num]['price'] #没购买一次，金额自减
                    print('你的金额还剩下:''\033[1;31;m%s\033[0m' % money)
                    print('\033[1;31;m%s\033[0m' % '成功加入购物车')
            elif num >= 0 and num <= len(goods)-1 and money < goods[num]['price']:
                print('\033[1;31;m%s\033[0m' % '余额不足')
            else:
                print('输入商品不存在,请重新输入')
        elif num == 'q' or num == 'Q':
            if len(new_res) > 0:
                print('你的金额还剩下:''\033[1;31;m%s\033[0m' % money)
                print('你购买商品如下:')
                for index, i in enumerate(new_res):
                    print('\033[1;31;m', end='')
                    print(index, i['name'], i['price'])
                    print('\033[0m', end='')
                time.sleep(1)
                print('欢迎下次光临')
                write_shop_file(new_res)
                write_money_file(money)
            break
        else:
            print('输入有误，请重新输入')
            continue



# 登入
def login():
    # 写帐号密码,判断是否是第一次登入，是就创建
    with open('file.user', 'r+', encoding='UTF-8') as f:
        date = f.read()
        if not date:
            print('这是您第一次登入，请创建你的帐号和密码')
            while True:
                username = input('请输入你要创建的帐号:').strip()
                pwd = input('请输入你要创建的密码:').strip()
                pwd2 = input('请再次输入你要创建的密码:').strip()
                if pwd == pwd2:
                    print('创建成功')
                    time.sleep(0.5)
                    f.write(username)
                    f.write('\n')
                    f.write(pwd)
                    f.flush()
                    break
                else:
                    print('创建失败，密码输入2次不一致')
                    time.sleep(0.5)
                    continue
        while True:
            Username = input('请输入帐号:').strip()
            Pwd = input('请输入密码:').strip()
            if con(Username, Pwd):
                print('登入成功')
                time.sleep(0.5)
                money = read_money_file() #用来判断是否是第一次登入，如果是第一次就跳过，直接输入金额
                if money != -1: # 用-1来做标记
                    print('你的金额还剩下:''\033[1;31;m%s\033[0m' % money)
                    print('你上次的购买记录是：')
                    old_res = read_shop_file()
                    for index, i in enumerate(old_res):
                        print('\033[1;31;m', end='')
                        print(index, i['name'], i['price'])
                        print('\033[0m', end='')
                    flag = input('请问是否继续上次购买，输入Y或者N:').strip()
                    if flag == 'Y' or flag == 'y':
                        old_buy()
                    elif flag == 'N' or flag == 'n':
                        new_buy()
                else:
                    new_buy()
                return True
            else:
                print('帐号或者密码错误，请重新输入')
                time.sleep(0.5)
                continue

login()