import re
import time
user_date = []
# 读取文件，以，号隔开存储在列表当中
with open('user_file', 'r+', encoding='UTF-8') as f:
    for line in f:
        user_date.append(re.split(',', line.strip()))


# 通过年纪查找
def find_age(num):
    flage = 0 #标记位，用来显示影响多少条
    for line in user_date:
        if line[2] >= num:
            print(line[0],line[1],line[2])
            flage +=1
    print(f'成功查询到{flage}条')
    time.sleep(1)


# 通过职位查找
def find_job(job):
    flage = 0
    for line in user_date:
        if job == line[4]:
            print(line)
            flage += 1
    print(f'成功查询到{flage}条')
    time.sleep(1)


# 通过入职时间查找
def find_year(years):
    flage = 0
    with open('user_file', 'r', encoding='UTF-8') as f:
        for line in f:
             if re.search(years, line):
                 print(line, end='')
                 flage += 1
        print(f'成功查询到{flage}条')
        time.sleep(1)


# 创建新员工纪录
def add_info(s):
    # 通过用正则，提取 add staff_table 后面的字段，然后用，隔开存储在列表当中
    list_s = re.split(',',re.split('add staff_table', s)[1])
    # 通过判断列表长度来确定ID 自增一次
    list_s.insert(0,len(user_date)+1)
    for line in user_date:
        # 判断电话号码是否重复以及是否是11位
        if len(list_s[3]) != 11 or list_s[3] == line[3]:
            print('电话号码重复或号码有误')
            time.sleep(1)
            return False
    user_date.append(list_s)
    print('添加成功')
    print(list_s)
    time.sleep(1)
    return True

# 删除数据
def del_info(s):
    # 通过使用正则提取要删除的ID号
    num = re.search('\d+', re.search('=\d+', s).group()).group()
    if int(num) <= len(user_date):
        a = user_date.pop(int(num)-1)
        print(a)
        print('删除成功')
        time.sleep(1)
    else:
        print('删除失败，数据不存在')


# 修改数据
def change_info(s):
    flage = 0
    # 使用正则来判断是修改部门还是修改年龄
    if re.findall('UPDATE staff_table SET dept=',s):
        # UPDATE staff_table SET dept= 用正则分隔出去，然后查找部门关键字，最后进行替换
        s1 = re.findall('\w+',re.split('UPDATE staff_table SET dept=',s)[1])
        for line in user_date:
            if s1[3] == line[4]:
                line[4] = s1[0]
                flage += 1
                print(line)
        print(f'成功处理{flage}条')
        time.sleep(1)
    elif re.findall('UPDATE staff_table SET age=', s):
        s2 = re.findall('\w+',str(re.split('UPDATE staff_table SET age=|WHERE name =', s)))
        for line in user_date:
            if s2[1] in line[1]:
                line[2] = s2[0]
                print(line)
                flage += 1
        print(f'成功处理{flage}条')
        time.sleep(1)

# 标记位，用作循环退出
flage = True
# 程序入口
while flage:
    msg = """
-------------------欢迎来到信息系统------------
1.数据查询（支持查询任何年龄，任何部门，以及任何入职年份）
2.数据增加
3.数据删除
4.数据修改
---------------------------------------------
"""
    print(msg)
    chiose = input('请输入编号进入对应功能,按q退出:').strip()
    if chiose.isdigit() and int(chiose) <= 4:
        if int(chiose) == 1:
            s = input('请输入SQL语句：')
            # 使用正则来判断是通过职位查询，年龄查询或者是入职年份查询
            if re.search('\d+', s):
                num = re.search('\d+', s).group()
                if len(num) == 2:
                    find_age(num)
                    time.sleep(2)
                elif len(num) == 4:
                    find_year(num)
            elif re.search('=\W+\w+', s):
                jobs = re.search('\w+', re.search('=\W+\w+', s).group()).group()
                find_job(jobs)
        elif int(chiose) == 2:
            s = input('请输入SQL语句：')
            add_info(s)
        elif int(chiose) == 3:
            s = input('请输入SQL语句：')
            del_info(s)
        elif int(chiose) == 4:
            s = input('请输入SQL语句：')
            change_info(s)
    elif chiose == 'q' or chiose == 'Q':
         flage = False
    else:
        print('输入有误，请重新输入')
        time.sleep(1)
        continue





